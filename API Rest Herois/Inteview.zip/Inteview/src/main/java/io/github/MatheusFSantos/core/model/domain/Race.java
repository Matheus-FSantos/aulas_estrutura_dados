package io.github.MatheusFSantos.core.model.domain;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.NUMBER)
public enum Race {
    HUMAN, ALIEN, DIVINE, CYBORG
}