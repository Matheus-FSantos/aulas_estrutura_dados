package io.github.matheusfsantos.model;

public class Comum extends Paciente {
	
	public Comum() {
		
	}
	
	public Comum(String nome, String sobrenome, Integer idade) {
		super(nome, sobrenome, idade);
	}
}