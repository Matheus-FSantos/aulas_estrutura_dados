package io.github.matheusfsantos.model.estruturas;

public class Pilha extends EstruturaEstatica {
	
}